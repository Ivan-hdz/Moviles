var DISQUSWIDGETS;

if (typeof DISQUSWIDGETS != 'undefined') {
    DISQUSWIDGETS.displayCount({"text":{"and":"y","comments":{"zero":"0 Comments","multiple":"{num} Comments","one":"1 Comment"}},"counts":[{"id":"3407 http:\/\/www.geekfactory.mx\/?p=3407","comments":55}]});
}